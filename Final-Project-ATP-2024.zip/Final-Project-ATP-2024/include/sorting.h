#ifndef SORTING_H
#define SORTING_H

#include "dto.h"

void sortByTitle(Playlist* playlist);

#endif